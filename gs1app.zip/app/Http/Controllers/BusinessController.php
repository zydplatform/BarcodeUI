<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator,Redirect,Response;
use Illuminate\Support\Facades\DB;
Use App\Models\Companies;
Use App\Models\Product;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Session;
use GuzzleHttp\Client;
use GuzzleHttp\ClientInterface;



class BusinessController extends Controller
{

    public function BusinessProfile(){
        return view('businessprofile');
    }

    public function registerBusiness(Request $request){
        $client = new Client();
        $url = "http://83.136.248.186:1701/businessProfiles";

        $params = [
            //If you have any Params Pass here
            'businessName' => $request->get('businessName'),
            'businessOwnership' => $request->get('businessOwnership'),
            'businessOwner' => $request->get('businessOwner'),
            'registrationNumber' => $request->get('registrationNumber'),
            'businessEmail' => $request->get('email'),
            'tinNumber' => $request->get('tinNumber'),
            'physicalAddress' => $request->get('physicalAddress'),
            'postalAddress' => $request->get('postalAddress'),
            // 'district' => $request->get('district'),            
            // 'country' => $request->get('country'),            
            // 'businessType' => $request->get('businessType'),            
            // 'businessLine' => $request->get('businessLine'),            
            'contacts' => $request->get('contacts'),
        ];

        // $headers = [
        //     'api-key' => 'k3Hy5qr73QhXrmHLXhpEh6CQ'
        // ];

        $response = $client->post($url, [
            'json' => $params,
            // 'headers' => $headers,
        ]);

        $responseBody = json_decode($response->getBody());

        return view('dashboard');
    }
    
    public function apiWithoutKey()
    {
        $client = new Client(); //GuzzleHttp\Client
        $url = "https://api.github.com/users/kingsconsult/repos";


        $response = $client->request('GET', $url, [
            'verify'  => false,
        ]);

        $responseBody = json_decode($response->getBody());

        return view('projects.apiwithoutkey', compact('responseBody'));
    }

    public function apiWithKey()
    {
        $client = new Client();
        $url = "https://dev.to/api/articles/me/published";

        $params = [
            //If you have any Params Pass here
        ];

        $headers = [
            'api-key' => 'k3Hy5qr73QhXrmHLXhpEh6CQ'
        ];

        $response = $client->request('GET', $url, [
            // 'json' => $params,
            'headers' => $headers,
            'verify'  => false,
        ]);

        $responseBody = json_decode($response->getBody());

        return view('projects.apiwithkey', compact('responseBody'));
    }

}

